# Cinemática Divertida 🚀

Um site educativo interativo para aprender física de forma divertida!

## 📚 Sobre o Projeto

Este site foi desenvolvido para tornar o aprendizado de cinemática mais envolvente e interativo para estudantes. Baseado em conteúdo educacional sobre velocidade, aceleração e movimento, o site oferece:

### ✨ Funcionalidades

- **Explicações Claras**: Conceitos de física explicados de forma simples
- **Calculadoras Interativas**: Ferramentas para calcular velocidade, aceleração e mais
- **Exercícios Práticos**: Quiz interativo com feedback imediato
- **Simulações Visuais**: Animações para ilustrar conceitos físicos
- **Design Responsivo**: Funciona perfeitamente em desktop e mobile

### 🎯 Tópicos Abordados

1. **Velocidade Média**
   - Conceitos fundamentais
   - Fórmula: Vm = ΔS/Δt
   - Calculadora interativa
   - Exemplos práticos

2. **Aceleração**
   - Taxa de variação da velocidade
   - Movimentos acelerados e retardados
   - Fórmula: a = Δv/Δt
   - Exercícios interativos

3. **Movimento Uniformemente Variado (MUV)**
   - Funções horárias
   - Equação de Torricelli
   - Calculadoras para cada fórmula

4. **Queda Livre**
   - Movimento sob ação da gravidade
   - Simulação visual
   - Fórmulas específicas

5. **Laboratório Virtual**
   - Quiz de conhecimentos
   - Conversor de unidades
   - Ferramentas educativas

### 🛠️ Tecnologias Utilizadas

- **HTML5**: Estrutura semântica
- **CSS3**: Design moderno e responsivo
- **JavaScript**: Interatividade e cálculos
- **MathJax**: Renderização de fórmulas matemáticas
- **Font Awesome**: Ícones
- **Google Fonts**: Tipografia

### 🎨 Design

- Paleta de cores educativa (azul, verde, laranja)
- Interface intuitiva e amigável
- Animações suaves
- Layout responsivo para todos os dispositivos

### 🚀 Como Usar

1. Acesse o site
2. Navegue pelos tópicos usando o menu ou cards
3. Use as calculadoras para resolver problemas
4. Teste seus conhecimentos no quiz
5. Explore as simulações visuais

### 📱 Compatibilidade

- ✅ Chrome, Firefox, Safari, Edge
- ✅ Desktop, Tablet, Mobile
- ✅ Todos os tamanhos de tela

### 🎓 Público-Alvo

- Estudantes do ensino médio
- Estudantes de física
- Professores de ciências
- Qualquer pessoa interessada em aprender física

### 📄 Licença

Este projeto é educacional e de código aberto.

---

**Desenvolvido com ❤️ para estudantes de física**

