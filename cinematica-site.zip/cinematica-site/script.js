// Navegação suave
document.addEventListener('DOMContentLoaded', function() {
    // Smooth scrolling para links de navegação
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Navegação por cards de tópicos
    const topicCards = document.querySelectorAll('.topic-card');
    topicCards.forEach(card => {
        card.addEventListener('click', function() {
            const topic = this.getAttribute('data-topic');
            const targetSection = document.querySelector(`#${topic}`);
            if (targetSection) {
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Inicializar MathJax
    if (window.MathJax) {
        MathJax.typesetPromise();
    }
});

// Calculadora de Velocidade Média
function calcularVelocidade() {
    const deslocamento = parseFloat(document.getElementById('deslocamento').value);
    const tempo = parseFloat(document.getElementById('tempo').value);
    const resultado = document.getElementById('resultado-velocidade');

    if (isNaN(deslocamento) || isNaN(tempo) || tempo === 0) {
        resultado.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Por favor, insira valores válidos!';
        resultado.className = 'result error';
        return;
    }

    const velocidade = deslocamento / tempo;
    const velocidadeKmh = velocidade * 3.6;

    resultado.innerHTML = `
        <div style="text-align: left;">
            <p><strong>Resultado:</strong></p>
            <p>Velocidade: <strong>${velocidade.toFixed(2)} m/s</strong></p>
            <p>Velocidade: <strong>${velocidadeKmh.toFixed(2)} km/h</strong></p>
        </div>
    `;
    resultado.className = 'result success';
}

// Calculadora de Aceleração
function calcularAceleracao() {
    const velInicial = parseFloat(document.getElementById('vel-inicial').value);
    const velFinal = parseFloat(document.getElementById('vel-final').value);
    const tempo = parseFloat(document.getElementById('tempo-acel').value);
    const resultado = document.getElementById('resultado-aceleracao');

    if (isNaN(velInicial) || isNaN(velFinal) || isNaN(tempo) || tempo === 0) {
        resultado.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Por favor, insira valores válidos!';
        resultado.className = 'result error';
        return;
    }

    // Converter km/h para m/s se necessário
    const vi = velInicial / 3.6; // Assumindo entrada em km/h
    const vf = velFinal / 3.6;
    
    const deltaV = vf - vi;
    const aceleracao = deltaV / tempo;
    
    const tipoMovimento = deltaV > 0 ? 'Acelerado' : 'Retardado';

    resultado.innerHTML = `
        <div style="text-align: left;">
            <p><strong>Resultado:</strong></p>
            <p>Variação de velocidade: <strong>${deltaV.toFixed(2)} m/s</strong></p>
            <p>Aceleração: <strong>${aceleracao.toFixed(2)} m/s²</strong></p>
            <p>Tipo de movimento: <strong>${tipoMovimento}</strong></p>
        </div>
    `;
    resultado.className = 'result success';
}

// Quiz de aceleração
function checkAnswer(button, isCorrect) {
    const options = document.querySelectorAll('.option');
    const feedback = document.getElementById('quiz-feedback');
    
    options.forEach(opt => {
        opt.disabled = true;
        if (opt === button) {
            opt.className = isCorrect ? 'option correct' : 'option incorrect';
        } else {
            opt.className = 'option';
        }
    });

    if (isCorrect) {
        feedback.innerHTML = '<i class="fas fa-check-circle"></i> Correto! A velocidade aumentou de 36 km/h para 54 km/h, caracterizando um movimento acelerado.';
        feedback.className = 'feedback correct';
    } else {
        feedback.innerHTML = '<i class="fas fa-times-circle"></i> Incorreto. Como a velocidade aumentou, trata-se de um movimento acelerado.';
        feedback.className = 'feedback incorrect';
    }
}

// Sistema de Tabs
function showTab(tabId) {
    // Esconder todas as abas
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(content => {
        content.classList.remove('active');
    });

    // Remover classe active de todos os botões
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.classList.remove('active');
    });

    // Mostrar aba selecionada
    const selectedTab = document.getElementById(tabId);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }

    // Ativar botão correspondente
    const activeButton = event.target;
    activeButton.classList.add('active');
}

// Calculadoras MUV
function calcularVelocidadeMUV() {
    const v0 = parseFloat(document.getElementById('v0-vel').value) || 0;
    const a = parseFloat(document.getElementById('a-vel').value) || 0;
    const t = parseFloat(document.getElementById('t-vel').value) || 0;
    const resultado = document.getElementById('resultado-vel-muv');

    if (t === 0) {
        resultado.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Por favor, insira um tempo válido!';
        resultado.className = 'result error';
        return;
    }

    const v = v0 + (a * t);

    resultado.innerHTML = `
        <div style="text-align: left;">
            <p><strong>Resultado:</strong></p>
            <p>Velocidade final: <strong>${v.toFixed(2)} m/s</strong></p>
            <p>Velocidade final: <strong>${(v * 3.6).toFixed(2)} km/h</strong></p>
        </div>
    `;
    resultado.className = 'result success';
}

function calcularPosicaoMUV() {
    const s0 = parseFloat(document.getElementById('s0-pos').value) || 0;
    const v0 = parseFloat(document.getElementById('v0-pos').value) || 0;
    const a = parseFloat(document.getElementById('a-pos').value) || 0;
    const t = parseFloat(document.getElementById('t-pos').value) || 0;
    const resultado = document.getElementById('resultado-pos-muv');

    if (t === 0) {
        resultado.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Por favor, insira um tempo válido!';
        resultado.className = 'result error';
        return;
    }

    const s = s0 + (v0 * t) + (0.5 * a * t * t);

    resultado.innerHTML = `
        <div style="text-align: left;">
            <p><strong>Resultado:</strong></p>
            <p>Posição final: <strong>${s.toFixed(2)} m</strong></p>
            <p>Deslocamento: <strong>${(s - s0).toFixed(2)} m</strong></p>
        </div>
    `;
    resultado.className = 'result success';
}

function calcularTorricelli() {
    const v0 = parseFloat(document.getElementById('v0-torr').value) || 0;
    const a = parseFloat(document.getElementById('a-torr').value) || 0;
    const ds = parseFloat(document.getElementById('ds-torr').value) || 0;
    const resultado = document.getElementById('resultado-torr');

    if (ds === 0) {
        resultado.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Por favor, insira um deslocamento válido!';
        resultado.className = 'result error';
        return;
    }

    const v2 = (v0 * v0) + (2 * a * ds);
    
    if (v2 < 0) {
        resultado.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Resultado inválido (velocidade imaginária)!';
        resultado.className = 'result error';
        return;
    }

    const v = Math.sqrt(v2);

    resultado.innerHTML = `
        <div style="text-align: left;">
            <p><strong>Resultado:</strong></p>
            <p>Velocidade final: <strong>${v.toFixed(2)} m/s</strong></p>
            <p>Velocidade final: <strong>${(v * 3.6).toFixed(2)} km/h</strong></p>
        </div>
    `;
    resultado.className = 'result success';
}

// Calculadoras de Queda Livre
function calcularVelocidadeQueda() {
    const t = parseFloat(document.getElementById('t-queda').value) || 0;
    const g = parseFloat(document.getElementById('g-vel').value) || 10;
    const resultado = document.getElementById('resultado-vel-queda');

    if (t === 0) {
        resultado.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Por favor, insira um tempo válido!';
        resultado.className = 'result error';
        return;
    }

    const v = g * t;

    resultado.innerHTML = `
        <div style="text-align: left;">
            <p><strong>Resultado:</strong></p>
            <p>Velocidade: <strong>${v.toFixed(2)} m/s</strong></p>
            <p>Velocidade: <strong>${(v * 3.6).toFixed(2)} km/h</strong></p>
        </div>
    `;
    resultado.className = 'result success';
}

function calcularAltura() {
    const t = parseFloat(document.getElementById('t-altura').value) || 0;
    const g = parseFloat(document.getElementById('g-altura').value) || 10;
    const resultado = document.getElementById('resultado-altura');

    if (t === 0) {
        resultado.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Por favor, insira um tempo válido!';
        resultado.className = 'result error';
        return;
    }

    const h = 0.5 * g * t * t;

    resultado.innerHTML = `
        <div style="text-align: left;">
            <p><strong>Resultado:</strong></p>
            <p>Altura: <strong>${h.toFixed(2)} m</strong></p>
        </div>
    `;
    resultado.className = 'result success';
}

function calcularTempoQueda() {
    const h = parseFloat(document.getElementById('h-tempo').value) || 0;
    const g = parseFloat(document.getElementById('g-tempo').value) || 10;
    const resultado = document.getElementById('resultado-tempo-queda');

    if (h <= 0) {
        resultado.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Por favor, insira uma altura válida!';
        resultado.className = 'result error';
        return;
    }

    const t = Math.sqrt((2 * h) / g);

    resultado.innerHTML = `
        <div style="text-align: left;">
            <p><strong>Resultado:</strong></p>
            <p>Tempo de queda: <strong>${t.toFixed(2)} s</strong></p>
        </div>
    `;
    resultado.className = 'result success';
}

// Simulação de Queda Livre
let simulationRunning = false;
let simulationInterval;

function startFallSimulation() {
    if (simulationRunning) return;
    
    simulationRunning = true;
    const object = document.getElementById('falling-object');
    const alturaSpan = document.getElementById('sim-altura');
    const tempoSpan = document.getElementById('sim-tempo');
    const velocidadeSpan = document.getElementById('sim-velocidade');
    
    let altura = 20; // metros
    let tempo = 0;
    let posicaoInicial = 20; // pixels do topo
    const alturaSimulacao = 300; // altura total da área de simulação
    const alturaChao = alturaSimulacao * 0.7; // 70% da altura
    
    object.style.top = posicaoInicial + 'px';
    
    simulationInterval = setInterval(() => {
        tempo += 0.1;
        
        // Calcular nova altura usando h = h0 - (1/2)gt²
        const alturaAtual = altura - (0.5 * 10 * tempo * tempo);
        
        if (alturaAtual <= 0) {
            // Objeto chegou ao chão
            clearInterval(simulationInterval);
            simulationRunning = false;
            alturaSpan.textContent = '0';
            tempoSpan.textContent = tempo.toFixed(1);
            velocidadeSpan.textContent = (10 * tempo).toFixed(1);
            object.style.top = alturaChao + 'px';
            return;
        }
        
        // Atualizar posição visual (proporcionalmente)
        const proporcao = alturaAtual / altura;
        const novaPosicao = posicaoInicial + (alturaChao - posicaoInicial) * (1 - proporcao);
        object.style.top = novaPosicao + 'px';
        
        // Atualizar informações
        alturaSpan.textContent = alturaAtual.toFixed(1);
        tempoSpan.textContent = tempo.toFixed(1);
        velocidadeSpan.textContent = (10 * tempo).toFixed(1);
        
    }, 100);
}

function resetFallSimulation() {
    if (simulationInterval) {
        clearInterval(simulationInterval);
    }
    simulationRunning = false;
    
    const object = document.getElementById('falling-object');
    object.style.top = '20px';
    
    document.getElementById('sim-altura').textContent = '20';
    document.getElementById('sim-tempo').textContent = '0';
    document.getElementById('sim-velocidade').textContent = '0';
}

// Sistema de Quiz
const quizQuestions = [
    {
        question: "Qual é a fórmula da velocidade média?",
        options: ["v = Δs/Δt", "v = s/t", "v = a×t", "v = v₀ + at"],
        correct: 0
    },
    {
        question: "Em um movimento acelerado, a velocidade:",
        options: ["Diminui", "Permanece constante", "Aumenta", "Varia aleatoriamente"],
        correct: 2
    },
    {
        question: "A aceleração da gravidade na Terra é aproximadamente:",
        options: ["9,8 m/s²", "10 km/h²", "9,8 km/s²", "10 m/h²"],
        correct: 0
    },
    {
        question: "Na queda livre, o tempo de queda depende:",
        options: ["Da massa do objeto", "Do tamanho do objeto", "Apenas da altura", "Da cor do objeto"],
        correct: 2
    }
];

let currentQuestion = 0;
let score = 0;

function startQuiz() {
    currentQuestion = 0;
    score = 0;
    document.getElementById('quiz-modal').style.display = 'block';
    showQuestion();
}

function showQuestion() {
    const quizContent = document.getElementById('quiz-content');
    const question = quizQuestions[currentQuestion];
    
    quizContent.innerHTML = `
        <div class="quiz-question">
            <h4>Pergunta ${currentQuestion + 1} de ${quizQuestions.length}</h4>
            <p>${question.question}</p>
            <div class="quiz-options">
                ${question.options.map((option, index) => 
                    `<button class="quiz-option" onclick="selectAnswer(${index})">${option}</button>`
                ).join('')}
            </div>
            <div id="quiz-result" class="quiz-result"></div>
        </div>
    `;
}

function selectAnswer(selectedIndex) {
    const question = quizQuestions[currentQuestion];
    const options = document.querySelectorAll('.quiz-option');
    const result = document.getElementById('quiz-result');
    
    options.forEach((option, index) => {
        option.disabled = true;
        if (index === question.correct) {
            option.classList.add('correct');
        } else if (index === selectedIndex && index !== question.correct) {
            option.classList.add('incorrect');
        }
    });
    
    if (selectedIndex === question.correct) {
        score++;
        result.innerHTML = '<p class="correct">✓ Correto!</p>';
    } else {
        result.innerHTML = '<p class="incorrect">✗ Incorreto. A resposta correta é: ' + question.options[question.correct] + '</p>';
    }
    
    setTimeout(() => {
        currentQuestion++;
        if (currentQuestion < quizQuestions.length) {
            showQuestion();
        } else {
            showQuizResult();
        }
    }, 2000);
}

function showQuizResult() {
    const quizContent = document.getElementById('quiz-content');
    const percentage = (score / quizQuestions.length) * 100;
    
    let message = '';
    if (percentage >= 80) {
        message = 'Excelente! Você domina os conceitos de cinemática!';
    } else if (percentage >= 60) {
        message = 'Bom trabalho! Continue estudando para melhorar ainda mais.';
    } else {
        message = 'Continue estudando! Revise os conceitos e tente novamente.';
    }
    
    quizContent.innerHTML = `
        <div class="quiz-final">
            <h4>Resultado Final</h4>
            <p class="score">Você acertou ${score} de ${quizQuestions.length} perguntas</p>
            <p class="percentage">${percentage.toFixed(0)}%</p>
            <p class="message">${message}</p>
            <button onclick="startQuiz()" class="btn btn-primary">Tentar Novamente</button>
        </div>
    `;
}

function closeQuiz() {
    document.getElementById('quiz-modal').style.display = 'none';
}

// Conversor de Unidades
function openConverter() {
    document.getElementById('converter-modal').style.display = 'block';
    
    // Adicionar event listeners para conversão automática
    const velInput = document.getElementById('vel-input');
    const velFrom = document.getElementById('vel-from');
    const velTo = document.getElementById('vel-to');
    const velResult = document.getElementById('vel-result');
    
    function convertVelocity() {
        const value = parseFloat(velInput.value) || 0;
        const from = velFrom.value;
        const to = velTo.value;
        
        let result = value;
        
        if (from === 'ms' && to === 'kmh') {
            result = value * 3.6;
        } else if (from === 'kmh' && to === 'ms') {
            result = value / 3.6;
        }
        
        velResult.textContent = result.toFixed(2);
    }
    
    velInput.addEventListener('input', convertVelocity);
    velFrom.addEventListener('change', convertVelocity);
    velTo.addEventListener('change', convertVelocity);
}

function closeConverter() {
    document.getElementById('converter-modal').style.display = 'none';
}

// Gráficos (placeholder)
function openGraphs() {
    alert('Funcionalidade de gráficos em desenvolvimento! Em breve você poderá visualizar gráficos interativos de movimento.');
}

// Fechar modais ao clicar fora
window.addEventListener('click', function(event) {
    const quizModal = document.getElementById('quiz-modal');
    const converterModal = document.getElementById('converter-modal');
    
    if (event.target === quizModal) {
        closeQuiz();
    }
    if (event.target === converterModal) {
        closeConverter();
    }
});

// Navegação mobile
document.addEventListener('DOMContentLoaded', function() {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }
});

// Animações de scroll
function animateOnScroll() {
    const elements = document.querySelectorAll('.topic-card, .formula-box, .calculator-box');
    
    elements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const elementVisible = 150;
        
        if (elementTop < window.innerHeight - elementVisible) {
            element.classList.add('animate');
        }
    });
}

window.addEventListener('scroll', animateOnScroll);

// Inicializar animações
document.addEventListener('DOMContentLoaded', function() {
    animateOnScroll();
});

